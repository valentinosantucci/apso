#include "tsplib_parser.h"
#include <cstdlib>
#include <cstring>

extern "C" {
	//LKH 2.0.7 from http://www.akira.ruc.dk/~keld/research/LKH/
	#include "LKH.h"
}



void parse_tsp_file(char* filename) {
	TraceLevel = 0;
	MaxMatrixDimension = 250000; //250k
	ProblemFileName = (char*)malloc(sizeof(char)*256);
	strcpy(ProblemFileName,filename);
	ReadProblem();
}


int tsp_get_dimension() {
	return Distance!=Distance_ATSP ? Dimension : Dimension/2; //empiricamente testato per ATSP su br17.atsp
}


void tsp_get_distance_matrix(int** d) {
	if (Distance != Distance_ATSP) { //simmetrico
		int n = Dimension;
		int k = 0;
		for (int i=0; i<n; i++)
			for (int j=0; j<i; j++)
				d[i][j] = d[j][i] = CostMatrix[k++];
		for (int i=0; i<n; i++)
			d[i][i] = 0;
	} else { //asimmetrico
		int n = Dimension/2; //empiricamente testato su br17.atsp
		int k = 0;
		for (int i=0; i<n; i++)
			for (int j=0; j<n; j++)
				d[i][j] = CostMatrix[k++];
	}
}


void free_tsp_parser() {
	FreeStructures();
}

