#ifndef TSPLIB_PARSER
#define TSPLIB_PARSER

void parse_tsp_file(char* filename);
int tsp_get_dimension();
void tsp_get_distance_matrix(int** d);
void free_tsp_parser();

#endif
