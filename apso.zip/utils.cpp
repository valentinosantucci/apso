#include "utils.h"
#include "random.h"
#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;


void randPermNInv(int* r, int n, int ninv) { //vedi https://www.lri.fr/~hansen/proceedings/2014/PPSN/papers/8672/86720332.pdf
	//some memory
	static int* factor = new int[n-1];	//static e' una forzatura qui!!!
	static int* usable = new int[n];	//static e' una forzatura qui!!!
	static int* id = usable;
	//init factor to all 0s, usable to "identity" and nusable to all (n-1)
	memset(factor,0,sizeof(int)*(n-1));
	pid(usable,n-1);
	int nusable = n-1;
	//increase ninv random elements of factor
	for (int i=0; i<ninv; i++) {
		int j = irand(nusable);
		int k = usable[j];
		factor[k]++;
		if (factor[k]==n-1-k)
			usable[j] = usable[--nusable];
	}
	//init identity
	pid(id,n);
	int nid = n;
	//convert factor to permutation in r removing elements from identity
	for (int i=0; i<n-1; i++) {
		int k = factor[i];
		r[i] = id[k];
		if (k<nid-1)
			memmove(id+k,id+k+1,sizeof(int)*(nid-1-k));
		nid--;
	}
	r[n-1] = id[0];
	//done
}


char* millis2str(unsigned long millis, char* s) {
	if (!s)
		s = new char[256]; //should be enough
	int ms = millis%1000;
	int sec = millis/1000;
	int min = sec/60;
	sec %= 60;
	int h = min/60;
	min %= 60;
	int d = h/24;
	h %= 24;
	if (d>0)
		sprintf(s,"%d days %d hours %d minutes %d.%03d seconds",d,h,min,sec,ms);
	else if (h>0)
		sprintf(s,"%d hours %d minutes %d.%03d seconds",h,min,sec,ms);
	else if (min>0)
		sprintf(s,"%d minutes %d.%03d seconds",min,sec,ms);
	else
		sprintf(s,"%d.%03d seconds",sec,ms);
	return s;
}


char* double2str(double n, char* s) {
	if (!s)
		s = new char[32];	//should be enough
	sprintf(s,"%.10lf",n);	//10 decimal digits
	int i = strlen(s);
	do {
		--i;
	} while (s[i]=='0' && i>0);
	if (s[i]=='.')
		s[i] = '\0';
	else
		s[i+1] = '\0';
	return s;
}


char* perm2str(int* p, int n, char* s) {
	if (!s)
		s = new char[4096];	//should be enough
	sprintf(s,"%d",p[0]);
	char* ptr;
	for (int i=1; i<n; i++) {
		ptr = s+strlen(s);
		sprintf(ptr," %d",p[i]);
	}
	return s;
}


bool permValid(int* p, int n) {
	bool objects[n];
	memset(objects,0,sizeof(bool)*n);
	for (int i=0; i<n; i++) {
		if (p[i]<0 || p[i]>=n || objects[p[i]])
			return false;
		objects[p[i]] = true;
	}
	return true;
}


void printPerm(int* p, int n) {
	for (int i=0; i<n; i++)
		cout << p[i] << " ";
	cout << endl;
}


int discardLine(FILE* f) {
	int c;
	do {
		c = fgetc(f);
	} while (c!='\n' && c!=EOF);
	return c;
}


int nlines(FILE* f) {
	int nl = 0;
	while (discardLine(f)!=EOF)
		nl++;
	return nl;
}


char* bits2str(uchar* b, int n, char* s) {
	if (!s)
		s = new char[4096]; //should be enough
	for (int i=0; i<n; i++)
		s[i] = b[i] ? '1' : '0';
	s[n] = '\0';
	return s;
}


bool bitsValid(uchar* b, int n) {
	for (int i=0; i<n; i++)
		if (b[i]<0 || b[i]>1)
			return false;
	return true;
}

