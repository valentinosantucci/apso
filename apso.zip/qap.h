#ifndef QAP_H
#define QAP_H

#define MINIMIZATION

#endif

