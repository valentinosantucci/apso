#ifndef LOPCC_H
#define LOPCC_H

#define MINIMIZATION

#endif

