#include "psop.h"
#include "pproblem.h"
#include "random.h"
#include "timer.h"
#include "utils.h"
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <iostream>
#include <iomanip>
using namespace std;


char inputFilename[256];
char outputFilename[256];
char alg[256];
unsigned int seed = 0;
unsigned long execTime;
int spso = 0;


void showUsage();
void readParams(int argc, char** argv);
void beforeExecution();
void afterExecution();
void writeOutputFile();
void checkSolution();


int main(int argc, char** argv) {
	psoDefaultParameters();
	readParams(argc,argv);
	initProblem(inputFilename);
	if (!seed)
		seed = randSeed();
	initRand(seed);
	psoAlloc();
	beforeExecution();
	setTimer();
	psoExec();
	execTime = getTimer();
	afterExecution();
	psoFree();
	destroyProblem();
	return EXIT_SUCCESS;
}


void showUsage() {
	cout << "USAGE:" << endl;
	cout << "  ./psop INPUT_FILE OUTPUT_FILE" << endl;
	cout << "ARGUMENTS:" << endl;
	cout << "  --verbose                                             [DEFAULT: no verbose]" << endl;
	cout << "  --seed      (INT)                                     [DEFAULT: random seed]" << endl;
	cout << "  --np        (INT)                                     [DEFAULT: 50]" << endl;
	cout << "  --omega     (DOUBLE)                                  [DEFAULT: 0.721]" << endl;
	cout << "  --c1        (DOUBLE)                                  [DEFAULT: 1.193]" << endl;
	cout << "  --c2        (DOUBLE)                                  [DEFAULT: 1.193]" << endl;
	cout << "  --topo      (ring|global|adrand)                      [DEFAULT: ring]" << endl;
	cout << "  --k         (INT)                                     [DEFAULT: 3]" << endl;
	cout << "  --geqp      (true|false)                              [DEFAULT: true]" << endl;
	cout << "  --maxnfes   (INT, 0 doesnt mind)                      [DEFAULT: 0]" << endl;
	cout << "  --maxtime   (DOUBLE, seconds, 0 doesnt mind)          [DEFAULT: 5]" << endl;
	cout << "  --targetfit (DOUBLE)                                  [DEFAULT: -inf or +inf]" << endl;
	cout << "  --spso      (2006|2007|0)                             [DEFAULT: 0]" << endl;
	cout << "  --restart   (0|1)                                     [DEFAULT: 1]" << endl;
	cout << "  --inertia   (classic|savetraj)                        [DEFAULT: classic]" << endl;
	cout << "  --hinit     (0|1)                                     [DEFAULT: 1]" << endl;
	cout << "  --sapso     (0|1)                                     [DEFAULT: 1]" << endl;
	cout << "  --bar       (0|1)                                     [DEFAULT: 0]" << endl;
	cout << "  --t         (INT)                                     [DEFAULT: 10000]" << endl;
}


void readParams(int argc, char** argv) {
	if (argc<3) {
		showUsage();
		exit(EXIT_FAILURE);
	}
	strcpy(alg,argv[0]);
	strcpy(inputFilename,argv[1]);
	strcpy(outputFilename,argv[2]);
	int i = 3;
	while (i<argc) {
		if (strcmp(argv[i],"--verbose")==0) {
			verbose = true;
			i++;
		} else if (strcmp(argv[i],"--seed")==0) {
			seed = atoi(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--np")==0) {
			np = atoi(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--omega")==0) {
			omega = atof(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--c1")==0) {
			c1 = atof(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--c2")==0) {
			c2 = atof(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--topo")==0) {
			if (strcmp(argv[i+1],"ring")==0)
				topo = TOPO_RING;
			else if (strcmp(argv[i+1],"global")==0)
				topo = TOPO_GLOBAL;
			else //adrand
				topo = TOPO_ADRAND;
			i += 2;
		} else if (strcmp(argv[i],"--k")==0) {
			k = atoi(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--geqp")==0) {
			gequalp = argv[i+1][0]=='t' || argv[i+1][0]=='T' || argv[i+1][0]=='1';
			i += 2;
		} else if (strcmp(argv[i],"--maxnfes")==0) {
			maxnfes = atoi(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--maxtime")==0) {
			maxtime = 1000*atof(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--targetfit")==0) {
			targetfit = atof(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--spso")==0) {
			spso = atoi(argv[i+1]);
			if (spso==2006) {
				topo = TOPO_RING;
				gequalp = false;
			} else if (spso==2007) {
				topo = TOPO_ADRAND;
				k = 3;
				gequalp = true;
			}
			i += 2;
		} else if (strcmp(argv[i],"--restart")==0) {
			dorestart = argv[i+1][0]=='t' || argv[i+1][0]=='T' || argv[i+1][0]=='1';
			i += 2;
		} else if (strcmp(argv[i],"--hinit")==0) {
			hinit = argv[i+1][0]=='t' || argv[i+1][0]=='T' || argv[i+1][0]=='1';
			i += 2; 
		} else if (strcmp(argv[i],"--bar")==0) {
			use_bar = argv[i+1][0]=='t' || argv[i+1][0]=='T' || argv[i+1][0]=='1';
			i += 2; 
		} else if (strcmp(argv[i],"--sapso")==0) {
			sapso = argv[i+1][0]=='t' || argv[i+1][0]=='T' || argv[i+1][0]=='1';
			i += 2;
		} else if (strcmp(argv[i],"--t")==0) {
			tgenRestart = atoi(argv[i+1]);
			i += 2;
		} else if (strcmp(argv[i],"--inertia")==0) {
			if (strcmp(argv[i+1],"classic")==0)
				inertia = INERTIA_CLASSIC;
			else { //savetraj
				inertia = INERTIA_SAVETRAJ;
				strcat(alg," --inertia savetraj");
			}
			i += 2;
		} else {
			cerr << "ERROR: " << argv[i] << " is not a valid argument" << endl;
			exit(EXIT_FAILURE);
		}
	}
	//if no termination criterion provided, set it to 5 seconds
#ifdef MAXIMIZATION
	if (!maxtime && !maxnfes && targetfit==PLUS_INF) {
#else
	if (!maxtime && !maxnfes && targetfit==MINUS_INF) {
#endif
		maxtime = 5000; //5 seconds
		cerr << "WARNING: No termination criterion has been provided, so it has been set to 5 seconds" << endl;
	}
	//done
}


void beforeExecution() {
	char smaxtime[200];
	millis2str(maxtime,smaxtime);
	cout << "Starting PSOP with parameters: " << endl;
	cout << "      inputfile = " << inputFilename << endl;
	cout << "     outputfile = " << outputFilename << endl;
	cout << "        verbose = " << (verbose?"true":"false") << endl;
	cout << "           spso = " << spso << endl;
	cout << "           seed = " << seed << endl;
	cout << "              n = " << n << endl;
	cout << "              m = " << m << endl;
	cout << "             np = " << np << endl;
	cout << "          omega = " << omega << endl;
	cout << "             c1 = " << c1 << endl;
	cout << "             c2 = " << c2 << endl;
	cout << "        inertia = " << (inertia==INERTIA_CLASSIC?"classic":"savetraj") << endl;
	cout << "           topo = " << (topo==TOPO_RING?"ring":(topo==TOPO_GLOBAL?"global":"adrand")) << endl;
	cout << "              k = " << k << " (valid only if topo=\"adrand\")" << endl;
	cout << "           geqp = " << gequalp << endl;
	cout << "            bar = " << (use_bar?"true":"false") << endl;
	cout << "        maxnfes = " << maxnfes << endl;
	cout << "        maxtime = " << smaxtime << endl;
	cout << "      targetfit = " << targetfit << endl;
	cout << "        restart = " << (dorestart?"true":"false") << endl;
	cout << "          hinit = " << (hinit?"true":"false") << endl;
	cout << "          sapso = " << (sapso?"true":"false") << endl;
	cout << "    tgenRestart = " << tgenRestart << endl;
	cout << "... running ..." << endl;
}


void afterExecution() {
	char sexecTime[256],sbesttime[256];
	millis2str(execTime,sexecTime);
	millis2str(besttime,sbesttime);
	cout << "... Execution finished. Summary of the results:" << endl;
	cout << "        bestfit = " << setprecision(10) << bestfit << endl;
	cout << "       bestnfes = " << bestnfes << endl;
	cout << "       besttime = " << sbesttime << endl;
	cout << "           nfes = " << nfes << endl;
	cout << "       exectime = " << sexecTime << endl;
	cout << "           ngen = " << ngen << endl;
	cout << "       nrestart = " << nrestart << endl;
	writeOutputFile();
	cout << "Full output saved in " << outputFilename << "." << endl;
	checkSolution();
}


void writeOutputFile() {
	FILE* f = fopen(outputFilename,"r");
	if (!f) {
		f = fopen(outputFilename,"w");
		fprintf(f,"alg,instance,enc,bestfit,bestnfes,besttime,nrestarts,nfes,exectime,seed,outputtype"); //parte comune con continui
		fprintf(f,",n,m,np,omega,c1,c2,inertia,topo,k,geqp,baric,maxnfes,maxtime,targetfit"); //altri parametri input
		fprintf(f,",ngen,bestperm\n"); //altri parametri output
		//fprintf(f,"inputfile,seed,n,m,np,omega,c1,c2,topo,k,geqp,maxnfes,maxtime,targetfit");		//input header
		//fprintf(f,",bestfit,bestnfes,besttime,nfes,exectime,ngen,nrestart,outputtype,bestperm\n");	//output header
	}
	fclose(f);
	char somega[32],sc1[32],sc2[32],stargetfit[64],sbestfit[64],sbestperm[4096],stopo[32];
	double2str(omega,somega);
	double2str(c1,sc1);
	double2str(c2,sc2);
	double2str(targetfit,stargetfit);
	double2str(bestfit,sbestfit);
	perm2str(bestp,n,sbestperm);
	if (topo==TOPO_RING)
		strcpy(stopo,"ring");
	else if (topo==TOPO_GLOBAL)
		strcpy(stopo,"global");
	else //TOPO_ADRAND
		strcpy(stopo,"adrand");
	f = fopen(outputFilename,"a");
	//output
	fprintf(f,"%s,%s,alg,%s,%d,%lu,%d,%d,%lu,%u,%c",alg,inputFilename,sbestfit,bestnfes,besttime,nrestart,nfes,execTime,seed,outputType==OUTPUT_NOTYPE?'n':(outputType==OUTPUT_TIME?'T':'E'));
	fprintf(f,",%d,%d,%d,%s,%s,%s,%s,%s,%d,%s,%s,%d,%lu,%s",n,m,np,somega,sc1,sc2,inertia==INERTIA_CLASSIC?"classic":"savetraj",stopo,k,gequalp?"true":"false",use_bar?"true":"false",maxnfes,maxtime,stargetfit);
	fprintf(f,",%d,%s\n",ngen,sbestperm);
	//fprintf(f,"%s,%u,%d,%d,%d,%s,%s,%s,%s,%d,%s,%d,%lu,%s",
	//	inputFilename,seed,n,m,np,somega,sc1,sc2,stopo,k,gequalp?"true":"false",maxnfes,maxtime,stargetfit);
	//fprintf(f,",%s,%d,%lu,%d,%lu,%d,%d,%c,%s\n",
	//	sbestfit,bestnfes,besttime,nfes,execTime,ngen,nrestart,outputType==OUTPUT_NOTYPE?'n':(outputType==OUTPUT_TIME?'T':'E'),sbestperm);
	//output 2 (se c'e' - che in realta' e' avvenuto prima)
	if (outputType2!=OUTPUT_NOTYPE) {
		double2str(bestfit2,sbestfit);
		perm2str(bestp2,n,sbestperm);
		fprintf(f,"%s,%s,alg,%s,%d,%lu,%d,%d,%lu,%u,%c",alg,inputFilename,sbestfit,bestnfes2,besttime2,nrestart2,nfes2,execTime2,seed,outputType2==OUTPUT_NOTYPE?'n':(outputType2==OUTPUT_TIME?'T':'E'));
		fprintf(f,",%d,%d,%d,%s,%s,%s,%s,%s,%d,%s,%s,%d,%lu,%s",n,m,np,somega,sc1,sc2,inertia==INERTIA_CLASSIC?"classic":"savetraj",stopo,k,gequalp?"true":"false",use_bar?"true":"false",maxnfes,maxtime,stargetfit);
		fprintf(f,",%d,%s\n",ngen2,sbestperm);
		/*fprintf(f,"%s,%u,%d,%d,%d,%s,%s,%s,%s,%d,%s,%d,%lu,%s",
			inputFilename,seed,n,m,np,somega,sc1,sc2,stopo,k,gequalp?"true":"false",maxnfes,maxtime,stargetfit);
		double2str(bestfit2,sbestfit);
		perm2str(bestp2,n,sbestperm);
		fprintf(f,",%s,%d,%lu,%d,%lu,%d,%d,%c,%s\n",
			sbestfit,bestnfes2,besttime2,nfes2,execTime2,ngen2,nrestart2,outputType2==OUTPUT_NOTYPE?'n':(outputType2==OUTPUT_TIME?'T':'E'),sbestperm);*/
	}
	//close file
	fclose(f);
}


void checkSolution() {
	if (!permValid(bestp,n)) {
		cerr << "ERROR: THE PERMUTATION PRODUCED IS INVALID!!!" << endl;
		exit(EXIT_FAILURE);
	}
	if (eval(bestp)!=bestfit) {
		cerr << "ERROR: THE FITNESS OF THE BEST PERMUTATION IS NOT EQUAL TO THE BEST FITNESS!!!" << endl;
		exit(EXIT_FAILURE);
	}
}

