#include "pproblem.h"


//global variables
char instance[256] = "none";	//instance filename
int n = 0;						//instance size
int m = 0;						//instance size
int* heurPerm = 0;				//heuristic permutation (null if not provided)


//functions
#ifdef PFSP_TFT
	#include "pfsp_tft.cpp"
#endif

#ifdef PFSP_MS
	#include "pfsp_ms.cpp"
#endif

#ifdef LOP
	#include "lop.cpp"
#endif

#ifdef LOPCC
	#include "lopcc.cpp"
#endif

#ifdef TSP
	#include "tsp.cpp"
#endif

#ifdef QAP
	#include "qap.cpp"
#endif

