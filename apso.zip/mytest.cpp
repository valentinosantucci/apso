#include "utils.h"
#include "randbs.cpp"

int main() {
	int n = 5;
	int x[n] = { 1,0,4,2,3};
	int y[n] = { 3,4,1,0,2};
	int iy[n];
	for (int i=0; i<n; i++) iy[y[i]]=i;
	//int r[n];
	//randPermNInv(r,n,3);
	//for(int i=0;i<n;i++) cout<<i<<" -> "<<r[i]<<endl;
	cout << kendalltau(x,iy,n) << endl;
	return 0;
}

