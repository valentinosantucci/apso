#!/bin/bash

rm dep_pfsp_tft
rm psop_pfsp_tft
rm fap_pfsp_tft

rm dep_pfsp_ms
rm psop_pfsp_ms
rm fap_pfsp_ms

rm dep_lop
rm psop_lop
rm fap_lop

rm dep_lopcc
rm psop_lopcc
rm fap_lopcc

rm dep_qap
rm psop_qap
rm fap_qap

rm dep_tsp
rm psop_tsp
rm fap_tsp

rm deb_nkl
rm psob_nkl
rm fab_nkl

make clean
