#ifndef LOP_H
#define LOP_H

#define MAXIMIZATION

#endif

