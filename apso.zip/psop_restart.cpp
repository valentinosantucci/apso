#include "randbs.cpp"


//Trigger a restart if all personal fitnesses are the same
bool restartTrigger_allTheSame() {
	if (!dorestart) return false;
	for (int i=1; i<np; i++)
		if (pop[0].pfit != pop[i].pfit) return false;
	return true;
}


//Trigger a restart if too much generations from last gbest improvement (or last restart)
bool restartTrigger_tooMuchFromLastImprovement() {
	if (!dorestart) return false;
	if (ngen-bestngen>=tgenRestart && ngen-ngenLastRestart>=tgenRestart) return true;
	return false;
}


bool localSearch(int* perm, double& fperm);


//Keep the best individual and randomly restart the others
void restart_bestRand() {
	//inizio gestione unsuccesful stages
#ifdef MAXIMIZATION
	static double prev_gbest = MINUS_INF;
#else
	static double prev_gbest = PLUS_INF;
#endif
	if (pop[ibest].pfit==prev_gbest)
		unsuc_stages_in_row++;
	else {
		unsuc_stages_in_row = 0;
		prev_gbest = pop[ibest].pfit;
	}
	//fine gestione unsuccesful stages
	//serve un po' di memoria
	static int* r1 = new int[n];
	static int* r2 = new int[n];
	static int* r2inv = new int[n];
	static int* tmp = r2inv;
	//per il best: mantieni il suo pbest + randomizza velocita (come in inizializzazione) + aggiorna posizione corrente con la nuova velocita
	//per gli altri: randomizza pbest
	//per tutti: reinizializza parametri (come in inizializzazione se sapso)
	for (int i=0; i<np; i++) {
		if (i==ibest) { //il best
			prand(n,r1);
			prand(n,r2);
			pinv(r2inv,r2,n);
			fdiff_bs(pop[ibest].v,0.5,r1,r2,0,r2inv,n); //r1inv non serve e quindi e' 0
			pcomp(tmp,pop[ibest].x,pop[ibest].v,n);
			memcpy(pop[ibest].x,tmp,sizeof(int)*n);
		} else { //gli altri
			prand(n,pop[i].p);
#ifdef MINIMIZATION
			pop[i].xfit = pop[i].pfit = PLUS_INF;
#else
			pop[i].xfit = pop[i].pfit = MINUS_INF;
#endif
		}
		//tutti
		if (sapso) {
			//omega
			pop[i].omega = omega+(urandi()*0.2-0.1);
			if (pop[i].omega<0.) pop[i].omega = 0.;
			else if (pop[i].omega>1.) pop[i].omega = 1.;
			pop[i].pomega = pop[i].omega;
			pop[i].vomega = 0.;
			//c1
			pop[i].c1 = c1+(urandi()*0.2-0.1);
			if (pop[i].c1<0.) pop[i].c1 = 0.;
			else if (pop[i].c1>2.) pop[i].c1 = 2.;
			pop[i].pc1 = pop[i].c1;
			pop[i].vc1 = 0.;
			//c2
			pop[i].c2 = c2+(urandi()*0.2-0.1);
			if (pop[i].c2<0.) pop[i].c2 = 0.;
			else if (pop[i].c2>2.) pop[i].c2 = 2.;
			pop[i].pc2 = pop[i].c2;
			pop[i].vc2 = 0.;
		}
		//done
	}
	//incrementa contatore restart e imposta generazione quando restart e' stato fatto
	nrestart++;
	ngenLastRestart = ngen;
cout<<unsuc_stages_in_row<<" "<<ngen<<" RESTART!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";//VALENTINO DEBUG
	//local search sul best
#ifdef MAXIMIZATION
	static double last_ls_fit = MINUS_INF;
#else
	static double last_ls_fit = PLUS_INF;
#endif
	if (pop[ibest].pfit!=last_ls_fit) {
		if (localSearch(pop[ibest].p,pop[ibest].pfit))
			updateBest(pop[ibest].pfit,pop[ibest].p,ibest);
		last_ls_fit = pop[ibest].pfit;
	}
	//fine
//cout<<ngen<<" RESTART!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n";//VALENTINO DEBUG
/* VECCHIO CODICE - MODIFICATO COME SOPRA IL 9 AGOSTO 2017
	static int* r = new int[n];
	for (int i=0; i<np; i++) {
		if (i==ibest)
			continue;
		//current position and its inverse and personal best
		prand(n,pop[i].x);
		pinv(pop[i].xinv,pop[i].x,n);
		//velocity as in http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf (PSO 2006 and 2007)
		prand(n,r);
		fdiff_bs(pop[i].v,0.5,r,pop[i].x,0,pop[i].xinv,n); //rinv non serve e quindi e' 0
		//fitnesses simply set to +-inf NOTA: Non serve randomizzare pbest ma basta mettere sua fitness a +-inf cosi' e' subito rimpiazzando al prossimo giro
#ifdef MINIMIZATION
		pop[i].xfit = pop[i].pfit = PLUS_INF;
#else
		pop[i].xfit = pop[i].pfit = MINUS_INF;
#endif
		//done
	}
	nrestart++;
*/
}


//Local Search based on Insertions (best-imp. style)
bool localSearch(int* perm, double& fperm) {
	int i,j,k,ib,jb,t;
	double incfit,tfit,bfit;
	bool imp;
	ib = jb = -1; //to avoid warnings
	incfit = fperm;
	//insertion best-improvement local search
	while (true) {
#ifdef MAXIMIZATION
		bfit = MINUS_INF;
#else
		bfit = PLUS_INF;
#endif
		for (i=0; i<n; i++) {
			for (j=0; j<n; j++) {
				if (i==j || i-1==j) continue;
				//inizio inserzione (i,j), cioe' l'elemento in posizione i va a finire in posizione j
				t = perm[i];
				if (i<j) for (k=i; k<j; k++) perm[k] = perm[k+1];
				else for (k=i; k>j; k--) perm[k] = perm[k-1];
				perm[j] = t;
				//fine inserzione (i,j)
				tfit = eval(perm); //valutazione fitness!!!
#ifdef MAXIMIZATION
				if (tfit>bfit) {
#else
				if (tfit<bfit) {
#endif
					bfit = tfit;
					ib = i;
					jb = j;
				}
				//inizio inserzione (j,i), cioe' l'elemento in posizione j va a finire in posizione i
				t = perm[j];
				if (j<i) for (k=j; k<i; k++) perm[k] = perm[k+1];
				else for (k=j; k>i; k--) perm[k] = perm[k-1];
				perm[i] = t;
				//fine inserzione (j,i)
			}
		}
#ifdef MAXIMIZATION
		if (bfit>incfit) {
#else
		if (bfit<incfit) {
#endif
			incfit = bfit;
			//inizio inserzione (ib,jb)
			t = perm[ib];
			if (ib<jb) for (k=ib; k<jb; k++) perm[k] = perm[k+1];
			else for (k=ib; k>jb; k--) perm[k] = perm[k-1];
			perm[jb] = t;
			//fine inserzione (ib,jb)
		} else break;
	}
	//controlla se c'e' improvement e fperm diventa incfit, mentre perm era gia' stata aggiornata prima
	imp = fperm!=incfit;
	fperm = incfit;
	return imp;
}

