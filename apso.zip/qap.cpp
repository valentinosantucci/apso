#include "qap.h"
#include "utils.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;

#define QAP_UPPER_BOUND 1500000000 //1.5miliardi

//local variables
static int** a = 0;		//flow matrix
static int** b = 0;		//distance matrix
static int* as = 0;		//flow matrix storage
static int* bs = 0;		//distance matrix storage


//read instance
void initProblem(char* filename) {
	//setup instance name
	strcpy(instance,filename);
	//open the file and check for errors
	FILE* f = fopen(filename,"r");
	if (!f) {
		cerr << "ERROR: Unable to open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//read n and check for errors
	if (fscanf(f,"%d",&n)!=1) {
		cerr << "ERROR: Unable to read N from " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//allocate memory and setup the pointers (Iliffe/display style)
	int n2 = n*n;
	as = new int[n2];
	a = new int*[n];
	for (int i=0; i<n; i++)
		a[i] = &as[i*n];
	bs = new int[n2];
	b = new int*[n];
	for (int i=0; i<n; i++)
		b[i] = &bs[i*n];
	//read the flow matrix entries and check for errors
	for (int i=0; i<n2; i++) {
		if (fscanf(f,"%d",&as[i])!=1) {
			cerr << "ERROR: Unable to read " << i << "th (0-based) entry of flow matrix A from " << filename << endl;
			exit(EXIT_FAILURE);
		}
	}
	//read the distance matrix entries and check for errors
	for (int i=0; i<n2; i++) {
		if (fscanf(f,"%d",&bs[i])!=1) {
			cerr << "ERROR: Unable to read " << i << "th (0-based) entry of distance matrix B from " << filename << endl;
			exit(EXIT_FAILURE);
		}
	}
	//close the file
	fclose(f);
	//done
}



//free memory
void destroyProblem() {
	delete[] a;
	delete[] as;
	delete[] b;
	delete[] bs;
}



//evaluate solution
double eval(int* x) {
	//see http://anjos.mgi.polymtl.ca/qaplib/inst.html
	int i,j;
	int fx = 0;
	for (i=0; i<n; i++)
		for (j=0; j<n; j++) {
			fx += a[i][j] * b[x[i]][x[j]];
			if (fx>QAP_UPPER_BOUND)
				return QAP_UPPER_BOUND;
		}
	return fx;
	//done
}

