#include "utils.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>

using namespace std;
//local variables
static int** d = 0;		//distance matrix
static int* dist = 0;		//distance matrix storage
static int n_cities;

// TSP file parser

void check(string &s1,const char *s2) {
	if(s1!=s2) {
		cerr << "Syntax error, expected '" << s2  << "', found '" << s1 << "'" << endl;
		exit(1);
	}
}

// EUC_2d

int nint(double x) { return (int)(x+.5); }

void load_problem_euc_2d(fstream &f) {
	int nc=n_cities;
	double x[n_cities], y[n_cities];
	string str1;
	f >> str1;
	check(str1,"NODE_COORD_SECTION");
	int j;
	for(int i=0;i<nc;i++) {
		f >> j;
		f >> x[j-1] >> y[j-1];
	}
	f >> str1;
	check(str1,"EOF");
	f.close();
	for(int i=0;i<nc;i++)
		for(int j=0;j<nc;j++)
			dist[i*nc+j]=nint(sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])));
}

// GEO

void load_problem_geo(fstream &f) {
	int nc=n_cities;
	double x[nc],y[nc];
	double lat[nc],lng[nc];
	int deg; double mn;
	int j;
	string str1;
	do {
		f >> str1;
	} while (str1!="NODE_COORD_SECTION");
	for(int i=0;i<nc;i++) {
		f >> j; j--;
		f >> x[j] >> y[j];
		deg=(int)(x[j]); mn=x[j]-deg;
		lat[j]=M_PI*(deg+5.0*mn/3.0)/180.0;
		deg=(int)(y[j]); mn=y[j]-deg;
		lng[j]=M_PI*(deg+5.0*mn/3.0)/180.0;
	}
	f.close();
	for(int i=0;i<nc;i++)
		for(int j=0;j<nc;j++) {
			const double RRR=6378.388;
			double 	q1=cos(lng[i]-lng[j]),
				q2=cos(lat[i]-lat[j]),
				q3=cos(lat[i]+lat[j]);
			dist[i*nc+j]=nint(RRR*acos(0.5*((1.0+q1)*q2-(1.0-q1)*q3))+1.0);	
		}
}

// EXPLICIT

void load_problem_explicit(fstream &f) {
	int nc=n_cities;
	string str1;
	f >> str1;
	check(str1,"EDGE_WEIGHT_FORMAT:");
	f >> str1;
	if(str1=="UPPER_ROW") {
		do {
			f >> str1;
		} while (str1!="EDGE_WEIGHT_SECTION");
		for(int i=0;i<nc;i++) {
			dist[i*nc+i]=0;
			for(int j=i+1;j<nc;j++) {
				f >> dist[i*nc+j];
				dist[j*nc+i]=dist[i*nc+j];
			}
		}
	}
	else if(str1=="FULL_MATRIX") {
		do {
			f >> str1;
		} while (str1!="EDGE_WEIGHT_SECTION");
		int nw=nc*nc;
		for(int i=0;i<nw;i++)
			f >> dist[i];
	}
	else if(str1=="LOWER_DIAG_ROW") {
		do {
			f >> str1;
		} while (str1!="EDGE_WEIGHT_SECTION");
		for(int i=0;i<nc;i++)
			for(int j=0;j<=i;j++) {
				f >> dist[i*nc+j];
				dist[j*nc+i]=dist[i*nc+j];
			}
	}
	else {
		cerr << "edge type " << str1 << " not known\n";
		exit(1);
	}
}

string get_header(fstream &f) {
	string s;
	f >> s;
	int l=s.length();
	if(s[l-1]!=':') {
		char c;
		f >> c;
		s=s+c;
	}
	if(s=="COMMENT:") {
		getline(f,s);
		return get_header(f);
	}
	return s;
}

void load_tsp(const char* fname) {
	fstream f; string str1;
	string nm; int nc;
	f.open(fname,ios::in);
	if(!f) {
		cerr << fname << " not found\n";
		exit(0);
	}
	str1=get_header(f);	check(str1,"NAME:");
	getline(f,nm);
	str1=get_header(f); check(str1,"TYPE:");
	f >> str1; check(str1,"TSP");
	str1=get_header(f); check(str1,"DIMENSION:");
	f >> nc;
	dist=new int[nc*nc];
	n_cities=nc;
	str1=get_header(f); check(str1,"EDGE_WEIGHT_TYPE:");
	f >> str1;
	cout << "edge type " << str1 << endl;
	//problem *res=nullptr;
	if(str1=="EUC_2D")
		load_problem_euc_2d(f);
	else if(str1=="GEO")
		load_problem_geo(f);
	/*
	else if(str1=="ATT")
		return new problem_att(f,nm,nc);
	else if(str1=="CEIL_2D")
		return new problem_ceil(f,nm,nc);*/
	else if(str1=="EXPLICIT")
		load_problem_explicit(f);
	else {
		cerr << "type " << str1 << " not found\n";
		exit(1);
	}
	cerr << "read TSP " << fname << " with " << nc << " cities\n";
}




//read instance
void initProblem(char* filename) {
	//setup instance name
	strcpy(instance,filename);
	//open and close the file to check for errors
	load_tsp(filename);
	//get dimension
	n = n_cities;
	//setup the pointers (Iliffe/display style)
	d = new int*[n];
	for (int i=0; i<n; i++)
		d[i] = &dist[i*n];
	//adjust n to n-1 to fix the last city
	m = n; //useless
	n--;
	//done
}



//free memory
void destroyProblem() {
	delete[] d;
	delete[] dist;
}



//evaluate solution
double eval(int* x) {
	//see https://www.lri.fr/~hansen/proceedings/2014/PPSN/papers/8672/86720332.pdf equation (2) but consider last city n
	//tour to evaluate: x[0] -> x[1] -> ... -> x[n-1] -> n > x[0] -> ...
	double fx = d[n][x[0]] + d[x[n-1]][n]; //weights n->x[0] and x[n-1]->n
	for (int i=1; i<n; i++)
		fx += d[x[i-1]][x[i]]; //wegihts x[0]->x[1] ... x[n-2]->x[n-1]
	return fx;
	//done
}

