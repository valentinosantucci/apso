#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;


typedef unsigned char uchar;
typedef unsigned long ulong;


inline void pinv(int* inv, int* x, int n) {					//Invert x in inv, both with length n
	for (int i=0; i<n; i++)
		inv[x[i]] = i;
}


inline void pcomp(int* z, int* x, int* y, int n) {			//Compose x*y in z, all with length n
	for (int i=0; i<n; i++)
		z[i] = x[y[i]];
}


inline void pcompl(int* x, int n) {							//Complement x in place
	for (int i=0; i<n; i++)
		x[i] = n-1-x[i];
}


inline void pid(int* x, int n) {							//Set x to the identity
	for (int i=0; i<n; i++)
		x[i] = i;
}


inline void prid(int* x, int n) {							//set x to the reverse identity
	for (int i=0; i<n; i++)
		x[i] = n-1-i;
}


inline void ainv(int* ai, int& nai, int* x, int n) {		//Get the adjacent inversions of x (with length n) in ai/nai
	nai = 0;
	for (int i=0; i<n-1; i++)
		if (x[i]>x[i+1])
			ai[nai++] = i;
}


inline void aswap(int* x, int i) {							//Adjacent swap
	int t = x[i];
	x[i] = x[i+1];
	x[i+1] = t;
}


inline void bid(uchar* x, int n) {							//identity bitstring
	memset(x,0,sizeof(uchar)*n);
}


void randPermNInv(int* r, int n, int ninv);					//Random permutation with ninv inversions
char* millis2str(unsigned long millis, char* s);			//Convert millis to string
char* double2str(double n, char* s);						//Convert double to string with 10 decimal digits
char* perm2str(int* p, int n, char* s);						//Convert a permutation to a string
bool permValid(int* p, int n);								//Check if a permutation is valid
void printPerm(int* p, int n);								//Print a permutation
int discardLine(FILE* f);									//Discard a line of the file
int nlines(FILE* f);										//Count the number of lines in a file
char* bits2str(uchar* b, int n, char* s);					//Convert a bitstring to a string (NORMAL representation)
bool bitsValid(uchar* b, int n);							//Check if a bitstring is valid (NORMAL representation)

#endif

