#ifndef RANDBS_CPP
#define RANDBS_CPP

#include <cmath>	//ceil
#include "random.h"


//functions defined later
inline void randbs(int* s, int& l, int* x, int n);
void fdiff_bs_onlypos(int* r, double f, int* x1, int* x2inv, int n);


//main function to call: compute scaled/extended difference r = f*(x1-x2) for every value of f
inline void fdiff_bs(int* r, double f, int* x1, int* x2, int* x1inv, int* x2inv, int n) {
	if (f>=0.)
		fdiff_bs_onlypos(r,f,x1,x2inv,n);
	else
		fdiff_bs_onlypos(r,-f,x2,x1inv,n);
}

//main function that returns also the length of the difference between 


//true function!!! Handle only positive f!!!
void fdiff_bs_onlypos(int* r, double f, int* x1, int* x2inv, int n) {
	//some variables
	static int nc2 = n*(n-1)/2;
	static int* z = new int[n];
	static int* s = new int[nc2];
	int l,k;
	//case f=0: simply set r to the identity
	if (f==0.) {
		pid(r,n);
		return;
	}
	//case f=1: simply set r to x2inv*x1
	if (f==1.) {
		pcomp(r,x2inv,x1,n);
		return;
	}
	//case 0<f<1: make z=x2inv*x1, decompose z in s/l, take the first part of s and compose in r
	if (f>0. && f<1.) {
		pcomp(z,x2inv,x1,n);
		randbs(s,l,z,n);
		k = ceil(f*l);
		pid(r,n);
		for (int i=0; i<k; i++)
			aswap(r,s[i]);
		return;
	}
	//case f>1: make z=x2inv*x1, copy z in r, decompose compl(z) in s/l, compose r with the first part of s
	if (f>1.) {
		pcomp(z,x2inv,x1,n);
		memcpy(r,z,sizeof(int)*n);
		pcompl(z,n);
		randbs(s,l,z,n);
		k = ceil(f*(nc2-l)) - (nc2-l); //because nc2-l is the length of z
		if (k>l)
			k = l;
		for (int i=0; i<k; i++)
			aswap(r,s[i]);
		return;
	}
	//if here there was an error
	cerr << "ERROR: F HAS A VALUE NOT VALID!!!" << endl;
	exit(EXIT_FAILURE);
	//done
}


//Randomized bubble sort
void randbs(int* s, int& l, int* x, int n) {
	//some variables
	static int* ai = new int[n];
	int i,j,t,nai;
	//compute adjacent inversions
	ainv(ai,nai,x,n);
	//initialize sequence length to 0
	l = 0;
	//sorting loop
	while (nai>0) {
		//randomly select an adjacent inversion (i,j)=(i,i+1)
		t = irand(nai);
		i = ai[t];
		j = i+1;
		//remove (i,j), i.e. i, from the list of adjacent inversions, i.e. ainv
		ai[t] = ai[--nai];
		//add previous inversion, i.e. (i-1,i)=(t,i), to ainv if the case
		t = i-1;
		if (i>0 && x[t]<x[i] && x[t]>x[j])
			ai[nai++] = t;
		//add next inversion, i.e. (i,i+1)=(j,t), to ainv if the case
		t = j+1;
		if (t<n && x[t]<x[i] && x[t]>x[j])
			ai[nai++] = j;
		//apply the swap (i,j) to x
		t = x[i];
		x[i] = x[j];
		x[j] = t;
		//save the swap in s (only i)
		s[l++] = i;
	}
	//done
}


//Inversion Count using mergesort - http://www.geeksforgeeks.org/counting-inversions/
int _mergeSort(int arr[], int temp[], int left, int right);
int _merge(int arr[], int temp[], int left, int mid, int right);
 
int invcount(int arr[], int array_size) {
	static int *temp = new int[array_size]; //(int *)malloc(sizeof(int)*array_size); //static aggiunto da me
	return _mergeSort(arr, temp, 0, array_size - 1);
}

int kendalltau(int* x, int* iy, int n) {
	static int* z = new int[n];
	for (int i=0; i<n; i++)
		z[i] = iy[x[i]];
	return invcount(z,n);
}
 
int _mergeSort(int arr[], int temp[], int left, int right) {
	int mid, inv_count = 0;
	if (right > left) {
		/* Divide the array into two parts and recursive call for each of the parts */
		mid = (right + left)/2;
		/* Inversion count will be sum of inversions in left-part, right-part and number of inversions in merging */
		inv_count  = _mergeSort(arr, temp, left, mid);
		inv_count += _mergeSort(arr, temp, mid+1, right);
		/*Merge the two parts*/
		inv_count += _merge(arr, temp, left, mid+1, right);
	}
	return inv_count;
}
 
int _merge(int arr[], int temp[], int left, int mid, int right) {
	int i, j, k;
	int inv_count = 0;
	i = left; /* i is index for left subarray*/
	j = mid;  /* j is index for right subarray*/
	k = left; /* k is index for resultant merged subarray*/
	while ((i <= mid - 1) && (j <= right)) {
		if (arr[i] <= arr[j])
			temp[k++] = arr[i++];
		else {
			temp[k++] = arr[j++];
			/*this is tricky -- see above explanation/diagram for merge()*/
			inv_count = inv_count + (mid - i);
		}
	}
 	/* Copy the remaining elements of left subarray (if there are any) to temp*/
	while (i <= mid - 1)
		temp[k++] = arr[i++];
 	/* Copy the remaining elements of right subarray (if there are any) to temp*/
	while (j <= right)
		temp[k++] = arr[j++];
	/*Copy back the merged elements to original array*/
	for (i=left; i <= right; i++)
		arr[i] = temp[i];
	return inv_count;
}

#endif

