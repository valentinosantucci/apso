#ifndef PFSP_MS_H
#define PFSP_MS_H

#define MINIMIZATION

#endif

