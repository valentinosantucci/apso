#include "lop.h"
#include "utils.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;


//local variables
static int** h = 0;		//i/o matrix interface
static int* hs = 0;		//inner i/o matrix storage


//read instance
void initProblem(char* filename) {
	//setup instance name
	strcpy(instance,filename);
	//open the file and check for errors
	FILE* f = fopen(filename,"r");
	if (!f) {
		cerr << "ERROR: Unable to open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//read n and check for errors
	if (fscanf(f,"%d",&n)!=1) {
		cerr << "ERROR: Unable to read N from " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//allocate memory and setup the pointers (Iliffe/display style)
	int n2 = n*n;
	hs = new int[n2];
	h = new int*[n];
	for (int i=0; i<n; i++)
		h[i] = &hs[i*n];
	//read the matrix entries and check for errors
	for (int i=0; i<n2; i++) {
		if (fscanf(f,"%d",&hs[i])!=1) {
			cerr << "ERROR: Unable to read " << i << "th (0-based) entry from " << filename << endl;
			exit(EXIT_FAILURE);
		}
	}
	//if there is heuristic permutation, read it
	int optimum;
	if (fscanf(f,"%d",&optimum)==1) { //discard the optimum, note that it doesnt work for XLOLIB but it is ok!
		heurPerm = new int[n];
		for (int i=0; i<n; i++) {
			if (fscanf(f,"%d",&heurPerm[i])!=1) {
				delete[] heurPerm;
				heurPerm = 0;
				break;
			}
		}
	}
	//close the file
	fclose(f);
	//done
}



//free memory
void destroyProblem() {
	delete[] h;
	delete[] hs;
	if (heurPerm) delete[] heurPerm;
}



//evaluate solution
double eval(int* x) {
	//sum up upper triangular part of h
	static int last = n-1;
	int fx = 0;
	int i,j,*r;
	for (i=0; i<last; i++) {
		r = h[x[i]];
		for (j=i+1; j<n; j++)
			fx += r[x[j]]; //the same of h[x[i]][x[j]] but faster
	}
	//return the sum
	return fx;
	//done
}

