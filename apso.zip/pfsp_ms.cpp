#include "pfsp_ms.h"
#include "utils.h"
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <iostream>
using namespace std;


//Branchless max between x and y (see http://aggregate.org/MAGIC)
#define FAST_MAX(x,y)	((x)-((((x)-(y))>>(sizeof(int)*8-1))&((x)-(y))))



//local variables
static int** ptime = 0;	//ptime matrix (n x m)
static int* ptimes = 0;	//ptimes matrix storage (Iliffe/display style)
static int* aux = 0;	//aux memory to compute fitness



//read instance
void initProblem(char* filename) {
	//setup instance name
	strcpy(instance,filename);
	//open the file and check for errors
	FILE* f = fopen(filename,"r");
	if (!f) {
		cerr << "ERROR: Unable to open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//discard a line (contains some text from ceberio) and check for eof error
	if (discardLine(f)==EOF)
		goto EOF_ERROR;
	//read n,m and discard the rest (it's useless) and check for eof error
	if (fscanf(f,"%d %d",&n,&m)!=2)
		goto EOF_ERROR;
	if (discardLine(f)==EOF)
		goto EOF_ERROR;
	//allocate memory and setup the pointers (Iliffe/display style)
	ptimes = new int[n*m];
	ptime = new int*[n];
	for (int i=0; i<n; i++)
		ptime[i] = ptimes+i*m;
	aux = new int[m];
	//discard a line (contains some text from ceberio) and check for eof error
	if (discardLine(f)==EOF)
		goto EOF_ERROR;
	//read matrix entries and check for eof error
	//in the file it is m x n, but ptime is n x m to favor memory locality
	for (int i=0; i<m; i++)
		for (int j=0; j<n; j++)
			if (fscanf(f,"%d",&ptime[j][i])!=1)
				goto EOF_ERROR;
	//close the file
	fclose(f);
	//return
	return;
	//eof error handling code
	EOF_ERROR:
	cerr << "ERROR: " << filename << " has a bad format" << endl;
	exit(EXIT_FAILURE);
	//done
}



//free memory
void destroyProblem() {
	delete[] ptime;
	delete[] ptimes;
	delete[] aux;
}



//evaluate solution
double eval(int* x) {
	//evaluate tft using "big" equation in ceberio's paper (using dynamic programming)
	static int lastm = m-1;
	int i,j;
	int job = x[0];
	aux[0] = ptime[job][0];          //part 1 of equation (2)
	for (j=1; j<m; j++)              //part 3 of equation (2)
		aux[j] = ptime[job][j] + aux[j-1];
	for (i=1; i<n; i++) {
		job = x[i];
		aux[0] += ptime[job][0];      //part 2 of equation (2)
		for (j=1; j<m; j++)           //part 4 of equation (2)
			aux[j] = ptime[job][j] + FAST_MAX(aux[j],aux[j-1]);
	}
	return aux[lastm];	//this is the makespan
	//done
}

