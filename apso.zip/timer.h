#ifndef TIMER_H
#define TIMER_H

void setTimer();
unsigned long getTimer();  //return the milliseconds elapsed from the last setTimer call

#endif

