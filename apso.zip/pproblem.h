#ifndef PPROBLEM_H
#define PPROBLEM_H

//global variables
extern char instance[256];	//instance filename
extern int n;				//instance size
extern int m;				//instance size
extern int* heurPerm;		//heuristic permutation (null if not provided)

//functions
void initProblem(char* filename);	//read instance
void destroyProblem();				//destroy memory
double eval(int* x);				//evaluate the permutation x

//other header from the problems
#ifdef PFSP_TFT
	#include "pfsp_tft.h"
#endif

#ifdef PFSP_MS
	#include "pfsp_ms.h"
#endif

#ifdef LOP
	#include "lop.h"
#endif

#ifdef LOPCC
	#include "lopcc.h"
#endif

#ifdef TSP
	#include "tsp.h"
#endif

#ifdef QAP
	#include "qap.h"
#endif

#endif

