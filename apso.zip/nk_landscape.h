#ifndef NK_LANDSCAPE_H
#define NK_LANDSCAPE_H

#define MAXIMIZATION

#endif

