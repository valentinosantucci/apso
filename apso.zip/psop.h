#ifndef PSOP_H
#define PSOP_H

//useful constants
#define PLUS_INF	(+1./0.)
#define MINUS_INF	(-1./0.)
#define TOPO_RING	1
#define TOPO_GLOBAL	2
#define TOPO_ADRAND	3
#define OUTPUT_NOTYPE	0
#define OUTPUT_TIME		1
#define OUTPUT_NFES		2
#define INERTIA_CLASSIC  0
#define INERTIA_SAVETRAJ 1

//input values
extern bool verbose;			//print infos if true
extern int np;					//population size
extern double omega;			//omega parameter
extern double c1;				//c1 parameter
extern double c2;				//c2 parameter
extern int topo;				//topology
extern bool gequalp;			//if true dont use term3 in update equation when g==p
extern int k;					//number of informants in the case of adaptive random topology
extern int maxnfes;				//maximum number of nfes allowed
extern unsigned long maxtime;	//maximum allowed time in milliseconds
extern double targetfit;		//target fitness to reach in order to terminate
extern bool dorestart;			//do restart or not (not saved in csv)
extern int inertia;				//decide which type of inertia term to use (classic or savetraj)
extern bool hinit;				//heuristic at initialization
extern bool sapso;				//self adaptive pso
extern bool use_bar;			//baricentrum of personal and global best
extern int tgenRestart;			//do restart every tgenRestart generations

//output values
extern double bestfit;			//best fitness so far
extern int* bestp;				//best permutation so far
extern int bestnfes;			//nfes when the best was discovered
extern int bestngen;			//ngen when the best was discovered
extern unsigned long besttime;	//time (in millis) when the best was discovered
extern int nfes;				//number of fitness evaluations performed
extern int ngen;				//number of generations performed
extern int nrestart;			//number of restart performed
extern int outputType;			//type of the output

//output values 2 (for double output in the csv file when 2 different termination criteria are set)
extern double bestfit2;			//best fitness so far
extern int* bestp2;				//best permutation so far
extern int bestnfes2;			//nfes when the best was discovered
extern unsigned long besttime2;	//time (in millis) when the best was discovered
extern int nfes2;				//number of fitness evaluations performed
extern int ngen2;				//number of generations performed
extern int nrestart2;			//number of restart performed
extern int outputType2;			//type of the output
extern unsigned long execTime2;	//execution time

//functions
void psoDefaultParameters();	//setup default parameters
void psoAlloc();				//allocate memory
void psoFree();					//free memory
void psoExec();					//execute pso

#endif

