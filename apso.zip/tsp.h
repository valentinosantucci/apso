#ifndef TSP_H
#define TSP_H

#define MINIMIZATION

#endif

