//SE DECOMMENTI/COMMENTI LE RIGHE CHE FINISCONO CON //vale PASSI DALL'IMPLEMENTAZIONE CHE NON FA USO DI VECTOR/PAIRS A QUELLA DEL CODICE DI GECCO2015

#include "nk_landscape.h"
#include <cstdio>
#include <iostream>
//#include <vector>//vale
//#include <utility>//vale
#include <cstring>
using namespace std;


//some variables
static int maxEvals = 0;									//useless now
//static vector< pair< vector<int>, vector<double> > > data;	//the same used in GECCO 2015 competition//vale
static int** mat1;//vale
static double** mat2;//vale



//read instance function
void initProblem(char* filename) {
	//setup instance name
	strcpy(instance,filename);
	//open the file and check for errors
	FILE* f = fopen(filename,"r");
	if (!f) {
		cerr << "ERROR: Unable to open " << filename << endl;
		exit(EXIT_FAILURE);
	}
	//get numGenes, maxEvalsPerInstance, K
	if (fscanf(f,"%d %d %d",&N,&maxEvals,&K)!=3)
		goto EOF_ERROR;
	n = N; //number of variables is the same of the number of subfunctions
	//read the data (one line for each subfunction)
	mat1 = new int*[N];//vale
	mat2 = new double*[N];//vale
	for (int i=0; i<N; i++) {
		int idummy;
		//vector<int> iarray;//vale
		mat1[i] = new int[K+1];//vale
		for (int j=0; j<K+1; ++j) {
			if (fscanf(f,"%d",&idummy)!=1)
				goto EOF_ERROR;
			//iarray.push_back(idummy);//vale
			mat1[i][j] = idummy;//vale
		}
		double ddummy;
		const int numFks = 1 << (K+1);
		//vector<double> darray;//vale
		mat2[i] = new double[numFks];//vale
		for (int j=0; j<numFks; ++j) {
			if (fscanf(f,"%lf",&ddummy)!=1)
				goto EOF_ERROR;
			//darray.push_back(ddummy);//vale
			mat2[i][j] = ddummy;//vale
		}
		//data.push_back(make_pair(iarray,darray));//vale
	}
	//if there is heuristic bitstring, read it
	if (discardLine(f)!=EOF) { //discard 1eof
		heurBits = new uchar[n];
		for (int i=0; i<n; i++) {
			int ch = fgetc(f);
			if (ch=='0' || ch=='1')
				heurBits[i] = ch=='0' ? 0 : 1;
			else {
				delete[] heurBits;
				heurBits = 0;
				break;
			}
		}
	}
	//exit with success
	return;
	//eof error handling code
	EOF_ERROR:
	cerr << "ERROR: " << filename << " has a bad format" << endl;
	exit(EXIT_FAILURE);
	//done
}



//destroy memory
void destroyProblem() {
	//data vector is automatically destroyed
	for (int i=0; i<N; i++) {//vale
		delete[] mat1[i];
		delete[] mat2[i];
	}//vale
	delete[] mat1;//vale
	delete[] mat2;//vale
}



//evaluate the bitstring x using the normal data structure
double eval(uchar* x) {
	double total = 0.;
	for (int i=0; i<n; ++i) {
		//const vector<int>& varIndices = data[i].first;//vale
		int* varIndices = mat1[i];//vale
		int fnTableIndex = 0;
		//for (unsigned int j=0; j<varIndices.size(); ++j) {//vale
		for (int j=0; j<K+1; j++) {//vale
			fnTableIndex <<= 1;
			fnTableIndex |= x[varIndices[j]]; //x is already 1 or 0
		}
		//total += data[i].second[fnTableIndex];//vale
		total += mat2[i][fnTableIndex];//vale
	}
	return total;
}



//evaluate the bitstring x using the shorter data structure
double eval(ulong* x) {
	//TODO
	return 0.;
}

