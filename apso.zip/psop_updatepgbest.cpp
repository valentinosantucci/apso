//update personal best
inline void updatePersonalBest() {
	for (int i=0; i<np; i++) {
#ifdef MINIMIZATION
		if (pop[i].xfit<=pop[i].pfit) {
#else
		if (pop[i].xfit>=pop[i].pfit) {
#endif
			pop[i].pfit = pop[i].xfit;
			memcpy(pop[i].p,pop[i].x,sizeof(int)*n);
			if (sapso) { //parameters also if self-adaptive
				pop[i].pomega = pop[i].omega;
				pop[i].pc1 = pop[i].c1;
				pop[i].pc2 = pop[i].c2;
			}
		}
	}
}


//BEGIN RING TOPOLOGY	in SPSO since 2006 (see http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf)
void updatePGbest_ring() {
	//call the personal best update
	updatePersonalBest();
	//local best with ring topology
	int j;
	for (int i=0; i<np; i++) {
		pop[i].g = i;
		j = (i+np-1)%np; //COME: j = i==0 ? np-1 : i-1;
#ifdef MINIMIZATION
		if (pop[j].pfit <= pop[pop[i].g].pfit)
#else
		if (pop[j].pfit >= pop[pop[i].g].pfit)
#endif
			pop[i].g = j;
		j = (i+1)%np;
#ifdef MINIMIZATION
		if (pop[j].pfit <= pop[pop[i].g].pfit)
#else
		if (pop[j].pfit >= pop[pop[i].g].pfit)
#endif
			pop[i].g = j;
	}
	//done
}
//END RING TOPOLOGY




//BEGIN GLOBAL TOPOLOGY
void updatePGbest_global() {
	//call the personal best update
	updatePersonalBest();
	//global topology
	for (int i=0; i<np; i++)
		pop[i].g = ibest;
	//done
}
//END GLOBAL TOPOLOGY




//BEGIN ADAPTIVE RANDOM TOPOLOGY
inline void randomizeInformants(int i) {
	//randomize the informants of the i-th particle
	static int* r = new int[np];
	r[0] = i;
	int t = 1;
	for (int j=0; j<np; j++)
		if (j!=i)
			r[t++] = j;
	shuffle(r+1,np-1);
	memcpy(pop[i].inf,r,sizeof(int)*(k+1));
}

void updatePGbest_adaptiveRandom() {
	//call the personal best update
	updatePersonalBest();
	//adaptive random topology
	//randomize the informants if the case
	if (!improvement) {
		for (int i=0; i<np; i++)
			randomizeInformants(i);
	}
	//compute the best informant
	for (int i=0; i<np; i++) {
		int g = pop[i].inf[0];
		for (int j=1; j<=k; j++)
#ifdef MINIMIZATION
			if (pop[j].pfit<=pop[g].pfit)
#else
			if (pop[j].pfit>=pop[g].pfit)
#endif
				g = j;
		pop[i].g = g;
	}
	//done
}
//END ADAPTIVE RANDOM TOPOLOGY

