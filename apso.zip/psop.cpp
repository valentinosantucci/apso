#include "psop.h"
#include "pproblem.h"
#include "random.h"
#include "utils.h"
#include "timer.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <climits>
using namespace std;


//extern values (defined in problem.h)
extern int n;			//instance size 1
extern int m;			//instance size 2


//input values (extern in psop.h)
bool verbose;			//print infos if true
int np;					//population size
double omega;			//omega parameter
double c1;				//c1 parameter
double c2;				//c2 parameter
int topo;				//topology
bool gequalp;			//if true dont use term3 in update equation when g==p
int k;					//number of informants in the case of adaptive random topology
int maxnfes;			//maximum number of nfes allowed
unsigned long maxtime;	//maximum allowed time in milliseconds
double targetfit;		//target fitness to reach in order to terminate
bool dorestart;			//do restart or not (not saved in csv)
int inertia;			//decide which type of inertia term to use (classic or savetraj)
bool hinit;				//heuristic at initialization
bool sapso;				//self adaptive pso
bool use_bar;			//baricentrum of personal and global best
int tgenRestart;		//do restart every tgenRestart generations

//output values (extern in psop.h)
double bestfit;			//best fitness so far
int* bestp;				//best permutation so far
int bestnfes;			//nfes when the best was discovered
int bestngen;			//ngen when the best was discovered
unsigned long besttime;	//time (in millis) when the best was discovered
int nfes;				//number of fitness evaluations performed
int ngen;				//number of generations performed
int nrestart;			//number of restart performed
int outputType;			//type of the output

//output values 2 (for double output in the csv file when 2 different termination criteria are set) (extern in psop.h)
double bestfit2;		//best fitness so far
int* bestp2;			//best permutation so far
int bestnfes2;			//nfes when the best was discovered
unsigned long besttime2;//time (in millis) when the best was discovered
int nfes2;				//number of fitness evaluations performed
int ngen2;				//number of generations performed
int nrestart2;			//number of restart performed
int outputType2;		//type of the output
unsigned long execTime2;//execution time


//inner variables
static bool improvement;//true if there was an improvement from the last iteration


//individual data structure
struct Individual {

	int* mem;		//memory for 4 perms
	int* x;			//current position
	int* xinv;		//inverse of x
	int* v;			//velocity
	int* p;			//personal best position
	int g;			//index of the particle that is the local best for this one
	double xfit;	//fitness of the current position
	double pfit;	//fitness of the personal best position
	int* inf;		//informants array used in the adaptive random topology

	double omega;	//sapso parameters
	double c1;		//sapso parameters
	double c2;		//sapso parameters
	double pomega;	//sapso parameters
	double pc1;		//sapso parameters
	double pc2;		//sapso parameters
	double vomega;	//sapso parameters
	double vc1;		//sapso parameters
	double vc2;		//sapso parameters

	Individual() {	//constructor
		mem  = new int[4*n];
		x    = mem;
		xinv = x + n;
		v    = xinv + n;
		p    = v + n;
		g    = -1;
		inf = 0;
	}

	~Individual() {	//destructor
		delete[] mem;
		if (inf)
			delete[] inf;
	}

};


//inner variables
Individual* pop;		//main population
int ibest;				//index of the best individual in the population
int ngenLastRestart = 0;//generation when last (re)start was done
int unsuc_stages_in_row = 0;//number of consecutive unsuccesful stages (between restarts)


//inner function pointers
void (*init)();
void (*updatePos)();
void (*updatePGbest)();
bool (*restartTrigger)();
void (*restart)();

//inner functions
bool term();
void evaluation();
void updateBest(double fit, int* p, int ind);
inline void printBestUpdate();
inline void copyOutput2();


//include of the implementations
#include "psop_init.cpp"
#include "psop_updatepos.cpp"
#include "psop_updatepgbest.cpp"
#include "psop_restart.cpp"


//set de default paramters
void psoDefaultParameters() {
	verbose = false;
	np = 50;
	omega = 0.721;	//as in http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf SPSO 2006 and 2007			//= 0.729;
	c1 = 1.193;		//as in http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf SPSO 2006 and 2007			//1.49445;	//2.05*0.729
	c2 = 1.193;		//as in http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf SPSO 2006 and 2007			//1.49445;	//2.05*0.729
	topo = TOPO_RING;
	gequalp = true;
	k = 3;
	maxnfes = INT_MAX;
	maxtime = INT_MAX;
	outputType = outputType2 = OUTPUT_NOTYPE;
	dorestart = false;//true;
	inertia = INERTIA_CLASSIC;
	hinit = false;//true;
	sapso = false;
	use_bar = false;
	tgenRestart = INT_MAX;//10000; //10mila
#ifdef MAXIMIZATION
	targetfit = PLUS_INF;
#else
	targetfit = MINUS_INF;
#endif
/*
	//PARAMETRI BUONI!!! ... MA ERANO PER CYB!!!
#ifdef PFSP_TFT
	np = 20;
	omega = 0.015;
	c1 = 1.74;
	c2 = 0.25;
	gequalp = true;
	hinit = true;
	dorestart = true;
	sapso = true;
	inertia = INERTIA_SAVETRAJ;
#endif
#ifdef LOP
	np = 20;
	omega = 0.008;
	c1 = 0.21;
	c2 = 1.55;
	gequalp = false;
	hinit = true;
	dorestart = true;
	sapso = true;
	inertia = INERTIA_SAVETRAJ;
#endif
*/
}


//allocate memory, setup function pointers and default parameters
void psoAlloc() {
	//allocate memory
	pop = new Individual[np];
	bestp = new int[n];
	bestp2 = new int[n];
	//init
	init = init_rand;
	//updatePGbest
	if (topo==TOPO_RING)
		updatePGbest = updatePGbest_ring;
	else if (topo==TOPO_GLOBAL)
		updatePGbest = updatePGbest_global;
	else { //TOPO_ADRAND
		updatePGbest = updatePGbest_adaptiveRandom;
		for (int i=0; i<np; i++) {
			pop[i].inf = new int[k+1];
			randomizeInformants(i);
		}
	}
	//updatePos
	if(use_bar)
		updatePos = updatePos_bar_noVmax_noConstr;
	else
		updatePos = updatePos_noVmax_noConstr;
	//restart trigger
	//restartTrigger = restartTrigger_allTheSame;
	restartTrigger = restartTrigger_tooMuchFromLastImprovement;
	//restart
	restart = restart_bestRand;
	//initialize other variables
	nfes = nrestart = 0;
	ngen = 1; //generazione 1 e' quella dell'inizializzazione
	improvement = true;
#ifdef MAXIMIZATION
	bestfit = MINUS_INF;
#else
	bestfit = PLUS_INF;
#endif
	//done
}


//free memory
void psoFree() {
	delete[] pop;
	delete[] bestp;
	delete[] bestp2;
}


//execute de algorithm
void psoExec() {
	init();
	updatePGbest();
	while (!term()) {
		ngen++;
		updatePos();
		evaluation();
		updatePGbest();
		if (restartTrigger()) {
			restart();
			updatePGbest();
		}
	}
}


//check de termination
bool localSearch(int* perm, double& fperm);
/*
bool term() {
	//CRITERIO ESPERIMENTI AGOSTO 2017
	#define MAX_UNSUC_STAGES_IN_ROW 10
	bool stop = false;
	if (unsuc_stages_in_row >= MAX_UNSUC_STAGES_IN_ROW || getTimer() >= maxtime) stop = true;
	if (stop && localSearch(pop[ibest].p,pop[ibest].pfit)) updateBest(pop[ibest].pfit,pop[ibest].p,ibest); //local search finale
	return stop;
}
*/
bool term() {
	unsigned long now = getTimer();
	if(now>=maxtime || nfes>=maxnfes) return true;
	else return false;
	//if (now>=1800000) return true; //CONTROLLO MEZZ'ORA SOLO PER TUNING FEBBRAIO 2017
	//if twoCond and one is verified, then copyOutput2
	//check termination condition
/*	if (
		(!maxtime || now>=maxtime) &&					//time
		(!maxnfes || nfes>=maxnfes) &&					//nfes
#ifdef MAXIMIZATION
		(targetfit==PLUS_INF || bestfit>=targetfit)		//fitness for maximization
#else
		(targetfit==MINUS_INF || bestfit<=targetfit)	//fitness for minimization
#endif
	   )
		return true;
	//otherwise do not terminate
	return false;
	//done
*/
}



//evaluate the y individuals
void evaluation() {
	improvement = false;
	for (int i=0; i<np; i++) {
		pop[i].xfit = eval(pop[i].x);
		nfes++;
		updateBest(pop[i].xfit,pop[i].x,i);
	}
}


//update the best so far
void updateBest(double fit, int* p, int ind) {
#ifdef MAXIMIZATION
	if (fit>bestfit) {
#else
	if (fit<bestfit) {
#endif
		bestfit = fit;
		memcpy(bestp,p,sizeof(int)*n);
		bestnfes = nfes;
		bestngen = ngen;
		besttime = getTimer();
		ibest = ind;
		improvement = true;
		if (verbose)
			printBestUpdate();
	}
}


//Print infos when the best so far is updated
void printBestUpdate() {
	static char stime[256];
	millis2str(besttime,stime);
	cerr << "bestfit = " << setprecision(10) << bestfit
		 << "\tnfes = " << nfes
		 << "\tngen = " << ngen
		 << "\ttime = " << stime 
		 << "\tnrestart = " << nrestart
		 << endl;
}


//Copy output values in variables2
void copyOutput2() {
	bestfit2 = bestfit;
	memcpy(bestp2,bestp,sizeof(int)*n);
	bestnfes2 = bestnfes;
	besttime2 = besttime;
	nfes2 = nfes;
	ngen2 = ngen;
	nrestart2 = nrestart;
}

