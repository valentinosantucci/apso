#include "randbs.cpp"

//Randomly initialize the population
void init_rand() {
	int* r = new int[n];
	for (int i=0; i<np; i++) {
		//current position and its inverse
		if (hinit && heurPerm && i==0) memcpy(pop[i].x,heurPerm,sizeof(int)*n);
		else prand(n,pop[i].x);
		pinv(pop[i].xinv,pop[i].x,n);
		//evaluate current position
		pop[i].xfit = eval(pop[i].x);
		nfes++;
		//velocity as in http://clerc.maurice.free.fr/pso/SPSO_descriptions.pdf (PSO 2006 and 2007)
		prand(n,r);
		fdiff_bs(pop[i].v,0.5,r,pop[i].x,0,pop[i].xinv,n); //rinv non serve e quindi e' 0
		//personal best simply set fitness to -+inf since it is updated after this function call
		if (hinit && heurPerm && i==0)
			pop[i].pfit = pop[i].xfit;
		else {
#ifdef MINIMIZATION
			pop[i].pfit = PLUS_INF;
#else
			pop[i].pfit = MINUS_INF;
#endif
		}
		//update best of this execution
		updateBest(pop[i].xfit,pop[i].x,i);
		//parameters if self-adaptive (perturbation +/- 0.1 of the passed ones)
		if (sapso) {
			//omega
			pop[i].omega = omega+(urandi()*0.2-0.1);
			if (pop[i].omega<0.) pop[i].omega = 0.;
			else if (pop[i].omega>1.) pop[i].omega = 1.;
			pop[i].pomega = pop[i].omega;
			pop[i].vomega = 0.;
			//c1
			pop[i].c1 = c1+(urandi()*0.2-0.1);
			if (pop[i].c1<0.) pop[i].c1 = 0.;
			else if (pop[i].c1>2.) pop[i].c1 = 2.;
			pop[i].pc1 = pop[i].c1;
			pop[i].vc1 = 0.;
			//c2
			pop[i].c2 = c2+(urandi()*0.2-0.1);
			if (pop[i].c2<0.) pop[i].c2 = 0.;
			else if (pop[i].c2>2.) pop[i].c2 = 2.;
			pop[i].pc2 = pop[i].c2;
			pop[i].vc2 = 0.;
		}
		//done
	}
	delete[] r;
	//global/local best indexes are initialized just after this function call
}

