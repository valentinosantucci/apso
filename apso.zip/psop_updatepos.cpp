#include "randbs.cpp"

//BEGIN UPDATEPOS WITHOUT VMAX AND WITHOUT CONSTRICTION FACTOR
void updatePos_noVmax_noConstr() {
	//some variables
	static int* term1 = new int[n];
	static int* term2 = new int[n];
	static int* term3 = new int[n];
	static int* tmp = new int[n];
	static int* iv = term2;
	static int* e = 0;
	double myomega,myc1,myc2,r1,r2;
	//make identity (only one time)
	if (!e) {
		e = new int[n];
		pid(e,n);
	}
	//for each particle
	for (int i=0; i<np; i++) {
		//get parameters
		if (sapso) {
			myomega = pop[i].omega;
			myc1 = pop[i].c1;
			myc2 = pop[i].c2;
		} else {
			myomega = omega;
			myc1 = c1;
			myc2 = c2;
		}
		//compute term1=omega*v depending on inertia type
		if (inertia==INERTIA_CLASSIC)
			fdiff_bs(term1,myomega,pop[i].v,e,0,e,n); //PERCHE' omega*v = omega*(v-e) ... inoltre e^-1 = e
		else { //INERTIA_SAVETRAJ
			fdiff_bs(tmp,1+myomega,pop[i].v,e,0,e,n); //tmp = (1+omega)*v
			pinv(iv,pop[i].v,n); //iv = v^{-1}
			pcomp(term1,iv,tmp,n); //term1 = iv*tmp = v^{-1} * (1+omega)*v
		}
		//compute term2=urandi()*c1*(p-x)
		r1 = urandi();
		fdiff_bs(term2,r1*myc1,pop[i].p,pop[i].x,0,pop[i].xinv,n);
		//compute term3=urandi()*c2*(g-x)
		if (gequalp && pop[i].g==i) {
			r2 = 0.;
			pid(term3,n);
		} else {
			r2 = urandi();
			fdiff_bs(term3,r2*myc2,pop[pop[i].g].p,pop[i].x,0,pop[i].xinv,n);
		}
		//update velocity using 6 different orders with equal probability
		switch (0) {//(irand(6)) {
			case 0:	//v=term1*term2*term3
				pcomp(tmp,term1,term2,n);
				pcomp(pop[i].v,tmp,term3,n);
				break;
			case 1: //v=term1*term3*term2
				pcomp(tmp,term1,term3,n);
				pcomp(pop[i].v,tmp,term2,n);
				break;
			case 2: //v=term2*term1*term3
				pcomp(tmp,term2,term1,n);
				pcomp(pop[i].v,tmp,term3,n);
				break;
			case 3: //v=term2*term3*term1
				pcomp(tmp,term2,term3,n);
				pcomp(pop[i].v,tmp,term1,n);
				break;
			case 4: //v=term3*term1*term2
				pcomp(tmp,term3,term1,n);
				pcomp(pop[i].v,tmp,term2,n);
				break;
			case 5: //v=term3*term2*term1
				pcomp(tmp,term3,term2,n);
				pcomp(pop[i].v,tmp,term1,n);
				break;
			default:
				break;
		}
		//update position
		pcomp(tmp,pop[i].x,pop[i].v,n);
		memcpy(pop[i].x,tmp,sizeof(int)*n);
		//update position inverse
		pinv(pop[i].xinv,pop[i].x,n);
		//if sapso update velocity and position of the parameters (clamping velocities to no more than 0.2, and clamping the positions too)
		if (sapso) {
			#define PARAMETERS_MAX_VELOCITY 0.2
			//omega
			pop[i].vomega = myomega*pop[i].vomega + r1*myc1*(pop[i].pomega-pop[i].omega) + r2*myc2*(pop[pop[i].g].pomega-pop[i].omega);
			if (pop[i].vomega<-PARAMETERS_MAX_VELOCITY) pop[i].vomega = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vomega>PARAMETERS_MAX_VELOCITY) pop[i].vomega = PARAMETERS_MAX_VELOCITY;
			pop[i].omega += pop[i].vomega;
			if (pop[i].omega<0.) pop[i].omega = 0.;
			else if (pop[i].omega>1.) pop[i].omega = 1.;
			//c1
			pop[i].vc1 = myomega*pop[i].vc1 + r1*myc1*(pop[i].pc1-pop[i].c1) + r2*myc2*(pop[pop[i].g].pc1-pop[i].c1);
			if (pop[i].vc1<-PARAMETERS_MAX_VELOCITY) pop[i].vc1 = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vc1>PARAMETERS_MAX_VELOCITY) pop[i].vc1 = PARAMETERS_MAX_VELOCITY;
			pop[i].c1 += pop[i].vc1;
			if (pop[i].c1<0.) pop[i].c1 = 0.;
			else if (pop[i].c1>2.) pop[i].c1 = 2.;
			//c2
			pop[i].vc2 = myomega*pop[i].vc2 + r1*myc1*(pop[i].pc2-pop[i].c2) + r2*myc2*(pop[pop[i].g].pc2-pop[i].c2);
			if (pop[i].vc2<-PARAMETERS_MAX_VELOCITY) pop[i].vc2 = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vc2>PARAMETERS_MAX_VELOCITY) pop[i].vc2 = PARAMETERS_MAX_VELOCITY;
			pop[i].c2 += pop[i].vc2;
			if (pop[i].c2<0.) pop[i].c2 = 0.;
			else if (pop[i].c2>2.) pop[i].c2 = 2.;
		}	
		//done
	}
	//done
}
//END UPDATEPOS WITHOUT VMAX AND WITHOUT CONSTRICTION FACTOR

void updatePos_bar_noVmax_noConstr() {
	//some variables
	static int* term1 = new int[n];
	static int* term2 = new int[n];
	static int* bar = new int[n];
	static int* tmp = new int[n];
	static int* iv = new int[n];
	static int* e = 0;
	double myomega,myc1,myc2,r1,r2;
	//make identity (only one time)
	if (!e) {
		e = new int[n];
		pid(e,n);
	}
	//for each particle
	for (int i=0; i<np; i++) {
		//get parameters
		if (sapso) {
			myomega = pop[i].omega;
			myc1 = pop[i].c1;
			myc2 = pop[i].c2;
		} else {
			myomega = omega;
			myc1 = c1;
			myc2 = c2;
		}
		//compute term1=omega*v depending on inertia type
		if (inertia==INERTIA_CLASSIC)
			fdiff_bs(term1,myomega,pop[i].v,e,0,e,n); //PERCHE' omega*v = omega*(v-e) ... inoltre e^-1 = e
		else { //INERTIA_SAVETRAJ
			fdiff_bs(tmp,1+myomega,pop[i].v,e,0,e,n); //tmp = (1+omega)*v
			pinv(iv,pop[i].v,n); //iv = v^{-1}
			pcomp(term1,iv,tmp,n); //term1 = iv*tmp = v^{-1} * (1+omega)*v
		}
		int ig=pop[i].g;
		r1=urandi(); r2=urandi();
		double alpha=r1*myc1, beta=r2*myc2, ab=alpha+beta;
		if(ab==0) {
			memcpy(pop[i].v,term1,sizeof(int)*n); }
		else {
			double gamma=alpha/ab;
			pinv(iv,pop[ig].p,n);
			fdiff_bs(tmp,1-gamma,pop[i].p,pop[ig].p,0,iv,n);
			pcomp(bar,pop[i].p,tmp,n);
			fdiff_bs(term2,ab,bar,pop[i].x,0,pop[i].xinv,n);
			if(urand()<0.5)
				pcomp(pop[i].v,term1,term2,n);
			else
				pcomp(pop[i].v,term2,term1,n);
		}
		//update position
		pcomp(tmp,pop[i].x,pop[i].v,n);
		memcpy(pop[i].x,tmp,sizeof(int)*n);
		//update position inverse
		pinv(pop[i].xinv,pop[i].x,n);
		//if sapso update velocity and position of the parameters (clamping velocities to no more than 0.2, and clamping the positions too)
		if (sapso) {
			#define PARAMETERS_MAX_VELOCITY 0.2
			//omega
			pop[i].vomega = myomega*pop[i].vomega + r1*myc1*(pop[i].pomega-pop[i].omega) + r2*myc2*(pop[pop[i].g].pomega-pop[i].omega);
			if (pop[i].vomega<-PARAMETERS_MAX_VELOCITY) pop[i].vomega = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vomega>PARAMETERS_MAX_VELOCITY) pop[i].vomega = PARAMETERS_MAX_VELOCITY;
			pop[i].omega += pop[i].vomega;
			if (pop[i].omega<0.) pop[i].omega = 0.;
			else if (pop[i].omega>1.) pop[i].omega = 1.;
			//c1
			pop[i].vc1 = myomega*pop[i].vc1 + r1*myc1*(pop[i].pc1-pop[i].c1) + r2*myc2*(pop[pop[i].g].pc1-pop[i].c1);
			if (pop[i].vc1<-PARAMETERS_MAX_VELOCITY) pop[i].vc1 = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vc1>PARAMETERS_MAX_VELOCITY) pop[i].vc1 = PARAMETERS_MAX_VELOCITY;
			pop[i].c1 += pop[i].vc1;
			if (pop[i].c1<0.01) pop[i].c1 = 0.01;
			else if (pop[i].c1>2.) pop[i].c1 = 2.;
			//c2
			pop[i].vc2 = myomega*pop[i].vc2 + r1*myc1*(pop[i].pc2-pop[i].c2) + r2*myc2*(pop[pop[i].g].pc2-pop[i].c2);
			if (pop[i].vc2<-PARAMETERS_MAX_VELOCITY) pop[i].vc2 = -PARAMETERS_MAX_VELOCITY;
			else if (pop[i].vc2>PARAMETERS_MAX_VELOCITY) pop[i].vc2 = PARAMETERS_MAX_VELOCITY;
			pop[i].c2 += pop[i].vc2;
			if (pop[i].c2<0.01) pop[i].c2 = 0.01;
			else if (pop[i].c2>2.) pop[i].c2 = 2.;
		}	
		//done
	}
	//done
}
