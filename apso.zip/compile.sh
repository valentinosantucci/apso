#!/bin/bash

#algs=$1
#probs=$2
algs="pso"
probs="pfsp_tft lop qap tsp"

if [ "$algs" == "" ]; then
	algs="de pso fa"
fi

if [ "$probs" == "" ]; then
	probs="pfsp_tft pfsp_ms lop lopcc qap tsp nkl"
fi

make SFMT.o
make random.o
make timer.o
make utils.o

for prob in $probs; do
	if [ "$prob" == "nkl" ]; then
		const="NK_LANDSCAPE"
		pb="b"
	else
		const=$(echo "$prob" | awk '{print toupper($0)}')
		pb="p"
	fi
	echo $const > problem.make
	if [ "$const" == "NK_LANDSCAPE" ]; then
		make bproblem.o
	else
		make pproblem.o
	fi
	for alg in $algs; do
		make ${alg}${pb}
		mv ${alg}${pb} ${alg}${pb}_${prob}
		rm ${alg}${pb}_obj.o
	done
	rm ?problem.o
done

rm *.o
